from pathlib import Path
import zipfile, json, hashlib
for d in [Path('outputs/小米平板6Pro-完整任务归档-20261014'),Path('outputs/小米平板6Pro-私有材料归档-20261014')]:
    m=json.loads((d/'manifest.json').read_text(encoding='utf-8'))
    sums=(d/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
    print(d.name, 'files',len(m['files']),'sums',len(sums))
    for line in sums:
        h,p=line.split('  ',1)
        q=d/p
        hh=hashlib.sha256(q.read_bytes()).hexdigest()
        assert hh==h,(p,hh,h)
    print('sha ok')
for z in Path('outputs').glob('*20261014.zip'):
    with zipfile.ZipFile(z) as f: print(z.name,'testzip=',f.testzip(),'entries=',len(f.namelist()),'size=',z.stat().st_size)
