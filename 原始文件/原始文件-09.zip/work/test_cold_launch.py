import subprocess,time,json,re,argparse,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--runs',type=int,default=6);a=p.parse_args()
out=Path('work/launcher-tests')/a.label;out.mkdir(parents=True,exist_ok=True)
adb=['adb','-s','1916b8f1']
def sh(c):return subprocess.check_output(adb+['shell',c],text=True,encoding='utf-8',errors='replace')
sh('input keyevent 224; wm dismiss-keyguard; input keyevent 3');time.sleep(.7)
result={}
for pkg,comp in [('com.android.settings','com.android.settings/.MainSettings'),('bin.mt.plus','bin.mt.plus/.MainLightIcon')]:
    out.joinpath(pkg+'-art.txt').write_text(sh('pm art dump '+pkg),encoding='utf-8')
    rows=[]
    for i in range(a.runs):
        sh('input keyevent 3; am force-stop '+pkg);time.sleep(.7)
        sh('dumpsys gfxinfo com.miui.home reset')
        text=sh('am start -W -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n '+comp)
        time.sleep(.7)
        gfx=sh('dumpsys gfxinfo com.miui.home framestats');out.joinpath(pkg+f'-{i}-gfx.txt').write_text(gfx,encoding='utf-8')
        row={'run':i,'launch_output':text,'frames':re.search(r'Total frames rendered: (\d+)',gfx).group(1) if 'Total frames rendered:' in gfx else None,'janky':re.search(r'Janky frames: (\d+)',gfx).group(1) if 'Janky frames:' in gfx else None}
        for key in ['ThisTime','TotalTime','WaitTime']: row[key]=int(re.search(key+r': (\d+)',text).group(1)) if re.search(key+r': (\d+)',text) else None
        rows.append(row);print(pkg,i,row['TotalTime'],row['WaitTime'],row['frames'],row['janky'],flush=True)
        sh('input swipe 1440 1790 1440 1050 120');time.sleep(.5)
    result[pkg]=rows
out.joinpath('results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
out.joinpath('battery.txt').write_text(sh('dumpsys battery'),encoding='utf-8')
print('MEDIANS', {pkg:statistics.median(r['TotalTime'] for r in rows) for pkg,rows in result.items()},flush=True)
