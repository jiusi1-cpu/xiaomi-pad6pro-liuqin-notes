from importlib.machinery import SourceFileLoader
from pathlib import Path
import json
a=SourceFileLoader('dev','work/adb-device.py').load_module()
d={'top':a.sh('top -b -n 1 -m 20'), 'battery':a.sh('dumpsys battery'),
   'memory':a.root('cat /proc/meminfo; cat /proc/pressure/memory'),
   'thermal':a.root('for z in /sys/class/thermal/thermal_zone*; do echo $(cat $z/type) $(cat $z/temp); done')}
Path('work/game-fps-research/prepared/steady-current-load.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
for k,v in d.items():
 print(k,v if k!='thermal' else '\n'.join(x for x in v.splitlines() if any(t in x for t in ('cpu','gpu','soc','skin'))))
