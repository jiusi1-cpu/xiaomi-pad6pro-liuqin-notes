import json
from pathlib import Path
p=Path('work/STATE.json');s=json.loads(p.read_text(encoding='utf-8'))
s['game_optimization']['spoof_target']='REDMAGIC tablet, not phone; NP05J officially maps to Gaming Tablet 3 Pro/Astra; user corrected phone suggestion'
s['game_optimization']['tablet_module_candidate']={
 'name':'ByRafaelSystem/Tablet-Spoofing- TabletSpoof v5.0',
 'url':'https://github.com/ByRafaelSystem/Tablet-Spoofing-',
 'release':'https://github.com/ByRafaelSystem/Tablet-Spoofing-/releases/tag/V5.0',
 'downloaded':'work/game-fps-research/tablet-spoof/TabletSpoof_v5_0_final.zip',
 'sha256':'aaa3a956c7aeaae8b11112829a0d54ee9e0a68cfce5e90c2907fddc25e7612d2',
 'digest_verified_against_github_asset':True,
 'installed':False,
 'defects':'Global resetprop, not per-process; redmagic branch erroneously sets characteristics=phone; revert does not restore 3 fingerprints and resets any manual wm density override; default game list excludes China pubgmhd; no current Android15/game proof',
 'alternative':'COPG permits custom per-app tablet profiles, no built-in NP05J found; standalone Zygisk needed; realFPS remains unverified'
}
p.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
