import subprocess,time,json,re,statistics,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--scene',action='store_true');p.add_argument('--mt',action='store_true');p.add_argument('--runs',type=int,default=6);a=p.parse_args()
adb=['adb','-s','1916b8f1'];out=Path('work/launcher-tests')/a.label;out.mkdir(parents=True,exist_ok=True)
def sh(s):return subprocess.check_output(adb+['shell',s],text=True,encoding='utf-8',errors='replace')
apps=[('com.android.settings','com.android.settings/.MainSettings'),('bin.mt.plus','bin.mt.plus/.MainLightIcon')]
if a.mt:apps=[('bin.mt.plus','bin.mt.plus/.MainLightIcon')]
if a.scene:apps=[('bin.mt.plus','bin.mt.plus/.MainLightIcon'),('com.omarea.vtools','com.omarea.vtools/.activities.ActivityMain')]
sh('input keyevent 224; wm dismiss-keyguard');rows={}
for pkg,comp in apps:
    valid=[];invalid=[]
    for attempt in range(a.runs+6):
        if len(valid)>=a.runs:break
        sh('input keyevent 3');time.sleep(.5);sh('am force-stop '+pkg);time.sleep(.3)
        pids=subprocess.run(adb+['shell','pidof',pkg],capture_output=True,text=True).stdout.strip()
        if pids:invalid.append({'attempt':attempt,'reason':'process not stopped','pid':pids});continue
        result=sh('am start -W -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n '+comp)
        fields={k:int(re.search(k+r': (\d+)',result).group(1)) if re.search(k+r': (\d+)',result) else None for k in ['ThisTime','TotalTime','WaitTime']}
        state=re.search(r'LaunchState: (\S+)',result)
        if fields['TotalTime'] is None or fields['TotalTime']<=0 or (state and state.group(1)!='COLD'):
            invalid.append({'attempt':attempt,'reason':'not cold','output':result});print('discard',pkg,flush=True);continue
        valid.append({'attempt':attempt,**fields,'output':result});print(pkg,'cold',len(valid),fields['TotalTime'],flush=True)
        time.sleep(.4);sh('input swipe 1440 1790 1440 1050 120');time.sleep(.3)
    rows[pkg]={'valid':valid,'invalid':invalid,'median_ms':statistics.median(r['TotalTime'] for r in valid) if valid else None}
    out.joinpath('results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    if len(valid)<a.runs:raise RuntimeError('Not enough valid cold runs')
print('MEDIANS',{pkg:v['median_ms'] for pkg,v in rows.items()},flush=True)
sh('input keyevent 3');out.joinpath('accessibility.txt').write_text(sh('dumpsys accessibility'),encoding='utf-8');out.joinpath('battery.txt').write_text(sh('dumpsys battery'),encoding='utf-8')
