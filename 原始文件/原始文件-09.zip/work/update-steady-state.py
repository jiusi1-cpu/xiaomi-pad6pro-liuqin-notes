import json
from pathlib import Path
p=Path('work/STATE.json'); s=json.loads(p.read_text(encoding='utf-8-sig'))
s['objective']='Sustained real120FPS PeaceElite; user paused manual input and authorized game/Scene settings, background cleanup and measurement'
s['user_authorizations']['redmagic_tablet_per_app_spoof']=True
s['game_optimization'].update({'spoof_installed':{'COPG':'v7.5.1','ZygiskNext':'v1.5.1','profile':'NP05J RedMagic Tablet3Pro, only com.tencent.tmgp.pubgmhd:blocked; realCPU preserved, all global extrasOFF','runtime':'served.jsonl confirms main and xg_vip_service NP05J; system model remains23046RP50C'},'60fps_fix':'secure miui_refresh_rate60 caused actualDisplay/SF cap60 despite user144. Changed to144, runtime144 verified','uncapped_short_sample':'25s training: unique3092 frames, mean124.806FPS, p50interval6.958ms p95=13.925ms; uncontrolled mix, not stable120 proof','scene_current':'EP20260620 enabled; powercfg.xml already game=performance, verify UI. Scene appops10022(ignore) changed allow to enable installed app list','current_game_graphics':'Visual verified fluent120FPS; antialias wasON, clickedOFF, pending final verification','coordination':'User now paused manual input; main agent may operate game/Scene UI'})
s['remaining']=['Verify Scene game performance UI and target physical120Hz only game preserving144HOME','Fresh optional background cleanup','Measure sustained actualgame frames and temperatures, user training movement','Deliver scoped rollback/result and save measured limits']
p.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
